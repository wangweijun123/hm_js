/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.hml?entry":
/*!************************************************************************************************!*\
  !*** D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.hml?entry ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/json.js!../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/template.js!./detail.hml */ "./lib/json.js!./lib/template.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.hml")
var $app_style$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/json.js!../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/style.js!./detail.css */ "./lib/json.js!./lib/style.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.css")
var $app_script$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/script.js!../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/babel-loader?presets[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./detail.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.js")

$app_define$('@app-component/detail', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/detail',undefined,undefined)

/***/ }),

/***/ "./lib/json.js!./lib/style.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.css":
/*!***********************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.css ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "flexDirection": "column"
  },
  ".button": {
    "marginTop": "10px"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.hml":
/*!**************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.hml ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/detail/detail:1",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/detail/detail:2"
      },
      "type": "div",
      "children": [
        {
          "attr": {
            "debugLine": "pages/detail/detail:3",
            "className": "title",
            "value": "This is the detail page."
          },
          "type": "text",
          "classList": [
            "title"
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:6",
        "type": "capsule",
        "value": "Go back"
      },
      "type": "button",
      "events": {
        "click": "launch"
      }
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:8",
        "className": "button",
        "type": "capsule",
        "value": "调用java内部服务"
      },
      "type": "button",
      "classList": [
        "button"
      ],
      "events": {
        "click": "callInternalService"
      }
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:10",
        "value": function () {return this.result}
      },
      "type": "text"
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:12",
        "className": "button",
        "type": "capsule",
        "value": "调用java外部进程的部服务"
      },
      "type": "button",
      "classList": [
        "button"
      ],
      "events": {
        "click": "callOutterService"
      }
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:13",
        "className": "button",
        "type": "capsule",
        "value": "js数据类型测试"
      },
      "type": "button",
      "classList": [
        "button"
      ],
      "events": {
        "click": "dataTypeTest"
      }
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:14",
        "className": "button",
        "type": "capsule",
        "value": "js array 数组测试"
      },
      "type": "button",
      "classList": [
        "button"
      ],
      "events": {
        "click": "arrayTest"
      }
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:15",
        "className": "button",
        "type": "capsule",
        "value": "js undefined 测试"
      },
      "type": "button",
      "classList": [
        "button"
      ],
      "events": {
        "click": "undefinedTest"
      }
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:16",
        "className": "button",
        "type": "capsule",
        "value": "js 函数内置一个nb的形参arguments数组"
      },
      "type": "button",
      "classList": [
        "button"
      ],
      "events": {
        "click": "useArguments"
      }
    },
    {
      "attr": {
        "debugLine": "pages/detail/detail:17",
        "className": "button",
        "type": "capsule",
        "value": "js 创建对象"
      },
      "type": "button",
      "classList": [
        "button"
      ],
      "events": {
        "click": "creatObjByConstructor"
      }
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.js":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/detail/detail.js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _typeof2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js"));

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var ABILITY_TYPE_EXTERNAL = 0;
var ABILITY_TYPE_INTERNAL = 1;
var ACTION_SYNC = 0;
var ACTION_ASYNC = 1;
var ACTION_MESSAGE_CODE_PLUS = 1001;
var _default = {
  data: {
    result: ""
  },
  launch: function launch() {
    _system["default"].back();
  },
  plusInnerService: function () {
    var _plusInnerService = (0, _asyncToGenerator2["default"])(_regenerator["default"].mark(function _callee() {
      var actionData, action, result, ret;
      return _regenerator["default"].wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              actionData = {};
              actionData.firstNum = 1024;
              actionData.secondNum = 2048;
              console.info("js MainAbility plus");
              action = {};
              action.bundleName = 'com.huawei.hiaceservice';
              action.abilityName = 'CalcInternalAbility';
              action.messageCode = ACTION_MESSAGE_CODE_PLUS;
              action.data = actionData;
              action.abilityType = ABILITY_TYPE_INTERNAL;
              action.syncOption = ACTION_ASYNC;
              console.info("js MainAbility callAbility ");
              _context.next = 14;
              return FeatureAbility.callAbility(action);

            case 14:
              result = _context.sent;
              console.info("js MainAbility result :" + result);
              ret = JSON.parse(result);
              console.info("js MainAbility ret :" + ret);
              console.info("js MainAbility ret.code :" + ret.code + ", abilityResult:" + ret.abilityResult);

              if (ret.code == 0) {
                console.info('MainAbility plus result is:' + JSON.stringify(ret.abilityResult));
                this.result = JSON.stringify(ret.abilityResult);
              } else {
                console.error('MainAbility plus error code:' + JSON.stringify(ret.code));
              }

            case 20:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, this);
    }));

    function plusInnerService() {
      return _plusInnerService.apply(this, arguments);
    }

    return plusInnerService;
  }(),
  callPlugOutterService: function () {
    var _callPlugOutterService = (0, _asyncToGenerator2["default"])(_regenerator["default"].mark(function _callee2() {
      var actionData, action, result, ret;
      return _regenerator["default"].wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              actionData = {};
              actionData.firstNum = 1024;
              actionData.secondNum = 2048;
              console.info("js MainAbility plus");
              action = {};
              action.bundleName = 'com.example.js_second_outservice';
              action.abilityName = 'CalcServiceAbility';
              action.messageCode = ACTION_MESSAGE_CODE_PLUS;
              action.data = actionData;
              action.abilityType = ABILITY_TYPE_EXTERNAL;
              action.syncOption = ACTION_ASYNC;
              console.info("js MainAbility callAbility ");
              _context2.next = 14;
              return FeatureAbility.callAbility(action);

            case 14:
              result = _context2.sent;
              console.info("js MainAbility result :" + result);
              ret = JSON.parse(result);
              console.info("js MainAbility ret :" + ret);
              console.info("js MainAbility ret.code :" + ret.code + ", abilityResult:" + ret.abilityResult);

              if (ret.code == 0) {
                console.info('MainAbility plus result is:' + JSON.stringify(ret.abilityResult));
                this.result = JSON.stringify(ret.abilityResult);
              } else {
                console.error('MainAbility plus error code:' + JSON.stringify(ret.code));
              }

            case 20:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, this);
    }));

    function callPlugOutterService() {
      return _callPlugOutterService.apply(this, arguments);
    }

    return callPlugOutterService;
  }(),
  callInternalService: function callInternalService() {
    console.info("js MainAbility callInternalService");
    this.plusInnerService();
    console.info("js MainAbility after plus");
  },
  callOutterService: function callOutterService() {
    console.info("js MainAbility callOutterService");
    this.callPlugOutterService();
    console.info("js MainAbility after plus");
  },
  dataTypeTest: function dataTypeTest() {
    var xx = 5;
    xx = 'hahah';
    console.info("xx:" + xx);
    var n1 = 0x19;
    console.info("n1:" + n1);
    console.info("MAX_VALUE:" + Number.MAX_VALUE);
    console.info("isNaN(1) ->" + isNaN(1));
    var str = "12";
    var strrrr = "xx";
    var bstr = 5;
    console.info("strrrr ->" + strrrr + " " + bstr);
    var b = "true";
    var numb = 1;

    if (b) {
      console.info("b ->" + b);
    }

    if (numb) {
      console.info("numb ->" + numb);
    }

    console.info("numb ->" + (0, _typeof2["default"])(numb));
    console.info("b ->" + (0, _typeof2["default"])(b));
    var strNum = "100";
    var nu = parseInt(strNum);
    console.info("nu ->" + (0, _typeof2["default"])(nu));
    var floatNum = 0.1 + 0.2;
    console.info("0.1 + 0.2 ->" + floatNum);

    for (var i = 0; i < 10; i++) {
      var str = "";

      for (var j = i; j < 10; j++) {
        str = str + '*';
      }

      console.info(str);
    }
  },
  plusxxx: function plusxxx(value, index, arr) {
    console.info(value + " " + index + " " + arr);
  },
  arrayTest: function arrayTest() {
    var array = new Array();

    for (var i = 0; i < 5; i++) {
      array.push(i);
    }

    array.push(6);
    array.push(7);

    for (var i = 0; i < array.length; i++) {
      console.info(i + " " + array[i]);
    }

    var array2 = [];

    for (var j = 0; j < 5; j++) {
      array2.push(j);
    }

    var newArray2 = [];
    console.info("###############");

    for (var i = 0; i < array2.length; i++) {
      console.info(i + " " + array2[i]);

      if (array2[i] < 3) {
        newArray2[newArray2.length] = array2[i];
      }
    }

    console.info(newArray2);
    var map = new Map();
    map.set("xxx", "duanxia");
    console.info(map.get("xxx"));
    newArray2.forEach(this.plusxxx);
    console.log(this.add(2, 3));
  },
  add: function add(n1, n2) {
    if (n1 > n2) {
      var re = n1;
    }

    console.log(re);
    return n1 + n2;
  },
  add2: function add2(n1, n2) {},
  add3: function add3() {
    console.log(arguments);
    console.log(arguments.length);

    for (var argumentsKey in arguments) {
      console.log(argumentsKey + " " + arguments[argumentsKey]);
    }
  },
  undefinedTest: function undefinedTest() {
    console.log(undefined == this.add2(2, 3));
  },
  useArguments: function useArguments() {
    this.add3(2, 3, 4, 5, 67);
  },
  createObj: function createObj() {
    var obj = {};
    var ob2 = new Object();
    var obj1 = {
      age: 18,
      name: 'duanxia',
      gender: '女',
      zuoai: function zuoai() {
        console.log("make love");
      }
    };
    console.log(obj1.gender);
    obj1.zuoai();
    var objArr = [{
      age: 18,
      name: 'duanxia',
      gender: '女',
      zuoai: function zuoai() {
        console.log("make love");
      }
    }, {
      age: 38,
      name: 'wangxiajiang',
      gender: '女',
      zuoai: function zuoai() {
        console.log("big love");
      }
    }];
    console.log("####### 打印数组对象 #######");

    for (var i = 0; i < objArr.length; i++) {
      console.log(objArr[i].age);
    }

    objArr.forEach(this.callbackfn);
  },
  callbackfn: function callbackfn(item) {
    console.log(item.name);
  },
  creatObjByConstructor: function creatObjByConstructor() {
    var obj = new Object();
    obj.name = "xxx";

    obj.sayHi = function (gequ) {
      console.log('我唱' + gequ);
    };

    console.log(obj.name);
    obj.sayHi('woaini');

    for (var element in obj) {
      console.log(element);
    }

    ;
    var d = new Date();
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/asyncToGenerator.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

module.exports = _asyncToGenerator;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@babel/runtime/regenerator/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! regenerator-runtime */ "./node_modules/regenerator-runtime/runtime.js");


/***/ }),

/***/ "./node_modules/regenerator-runtime/runtime.js":
/*!*****************************************************!*\
  !*** ./node_modules/regenerator-runtime/runtime.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = (function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   true ? module.exports : undefined
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}


/***/ })

/******/ });
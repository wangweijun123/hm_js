package com.example.java_client;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}

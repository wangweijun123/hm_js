package com.example.java_client;

import com.example.java_client.slice.MainAbilitySlice;
import com.example.java_service.IMyIdlInterface;
import com.example.java_service.MyIdlInterfaceProxy;
import com.example.java_service.MyIdlInterfaceStub;
import ohos.aafwk.ability.Ability;
import ohos.aafwk.ability.IAbilityConnection;
import ohos.aafwk.content.Intent;
import ohos.aafwk.content.Operation;
import ohos.bundle.ElementName;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;
import ohos.rpc.IRemoteObject;
import ohos.rpc.RemoteException;

public class MainAbility extends Ability {
    public static final HiLogLabel LABEL_LOG = new HiLogLabel(3, 0xD001100, "MainAbility");
    @Override
    public void onStart(Intent in) {
        super.onStart(in);
        super.setMainRoute(MainAbilitySlice.class.getName());

        connectAbility();
    }

    private void connectAbility() {
        Intent intent = new Intent();
        Operation operation = new Intent.OperationBuilder()
                .withDeviceId("")
                .withBundleName("com.example.java_service")
                .withAbilityName("com.example.java_service.ServiceAbility")
                .build();
        intent.setOperation(operation);
        connectAbility(intent, connection);
    }

    // 创建连接回调实例
    private IAbilityConnection connection = new IAbilityConnection() {
        // 连接到Service的回调
        @Override
        public void onAbilityConnectDone(ElementName elementName,
                                         IRemoteObject iRemoteObject, int resultCode) {
            // 在这里开发者可以拿到服务端传过来IRemoteObject对象，从中解析出服务端传过来的信息
            IMyIdlInterface iMyIdlInterface = MyIdlInterfaceStub.asInterface(iRemoteObject);
            try {
                int plus = iMyIdlInterface.plus(1, 2);
                HiLog.info(LABEL_LOG, "server plus :" + plus);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }


        // 断开与连接的回调
        @Override
        public void onAbilityDisconnectDone(ElementName elementName, int resultCode) {
        }
    };

}

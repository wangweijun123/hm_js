/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.hml?entry":
/*!*********************************************************************************************!*\
  !*** D:/dev_hm/hm_workspace/js_first/entry/src/main/js/default/pages/index/index.hml?entry ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/json.js!../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.hml")
var $app_style$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/json.js!../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/style.js!./index.css */ "./lib/json.js!./lib/style.js!../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.css")
var $app_script$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/lib/script.js!../../../../../../../../../hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/babel-loader?presets[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.js")

$app_define$('@app-component/index', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/index',undefined,undefined)

/***/ }),

/***/ "./lib/json.js!./lib/style.js!../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.css":
/*!********************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/dev_hm/hm_workspace/js_first/entry/src/main/js/default/pages/index/index.css ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "flexDirection": "column"
  },
  ".title-section": {
    "flexDirection": "row",
    "height": "60px",
    "marginBottom": "5px",
    "marginTop": "10px"
  },
  ".title": {
    "alignItems": "flex-start",
    "flexDirection": "column",
    "paddingLeft": "60px",
    "paddingRight": "160px"
  },
  ".name": {
    "fontSize": "20px"
  },
  ".sub-title": {
    "fontSize": "15px",
    "color": "#7a787d",
    "marginTop": "10px"
  },
  ".swiper-style": {
    "height": "250px",
    "width": "350px",
    "indicatorColor": "#4682b4",
    "indicatorSelectedColor": "#f0e68c",
    "indicatorSize": "10px",
    "marginLeft": "50px"
  },
  ".image-mode": {
    "objectFit": "contain"
  },
  ".color-column": {
    "flexDirection": "row",
    "alignContent": "center",
    "marginTop": "20px"
  },
  ".color-item": {
    "height": "50px",
    "width": "50px",
    "marginLeft": "50px",
    "paddingLeft": "10px",
    "backgroundColor:focus": "#FFFFFF"
  },
  ".description-first-paragraph": {
    "paddingLeft": "60px",
    "paddingRight": "60px",
    "paddingTop": "30px"
  },
  ".description": {
    "color": "#7a787d",
    "fontSize": "15px"
  },
  ".cart": {
    "justifyContent": "center",
    "marginTop": "20px"
  },
  ".cart-text": {
    "fontSize": "20px",
    "textAlign": "center",
    "width": "300px",
    "height": "50px",
    "backgroundColor": "#6495ed",
    "color": "#FFFFFF"
  },
  ".cart-text-focus": {
    "fontSize": "20px",
    "textAlign": "center",
    "width": "300px",
    "height": "50px",
    "backgroundColor": "#4169e1",
    "color": "#FFFFFF"
  },
  ".add-cart-text": {
    "fontSize": "20px",
    "textAlign": "center",
    "width": "300px",
    "height": "50px",
    "backgroundColor": "#ffd700",
    "color": "#FFFFFF"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.hml":
/*!***********************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/dev_hm/hm_workspace/js_first/entry/src/main/js/default/pages/index/index.hml ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/index/index:1",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/index/index:2",
        "className": "title-section"
      },
      "type": "div",
      "classList": [
        "title-section"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/index/index:3",
            "className": "title"
          },
          "type": "div",
          "classList": [
            "title"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/index/index:4",
                "className": "name",
                "value": "Food"
              },
              "type": "text",
              "classList": [
                "name"
              ]
            },
            {
              "attr": {
                "debugLine": "pages/index/index:5",
                "className": "sub-title",
                "value": "Choose What You Like"
              },
              "type": "text",
              "classList": [
                "sub-title"
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/index/index:8"
      },
      "type": "div",
      "children": [
        {
          "attr": {
            "debugLine": "pages/index/index:9",
            "id": "swiperImage",
            "className": "swiper-style"
          },
          "type": "swiper",
          "id": "swiperImage",
          "classList": [
            "swiper-style"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/index/index:10",
                "src": function () {return this.$item},
                "className": "image-mode",
                "focusable": "true"
              },
              "type": "image",
              "classList": [
                "image-mode"
              ],
              "repeat": function () {return this.imageList}
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/index/index:12",
            "className": "container"
          },
          "type": "div",
          "classList": [
            "container"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/index/index:13",
                "className": "description-first-paragraph"
              },
              "type": "div",
              "classList": [
                "description-first-paragraph"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/index/index:14",
                    "className": "description",
                    "value": function () {return this.descriptionFirstParagraph}
                  },
                  "type": "text",
                  "classList": [
                    "description"
                  ]
                }
              ]
            },
            {
              "attr": {
                "debugLine": "pages/index/index:16",
                "className": "color-column"
              },
              "type": "div",
              "classList": [
                "color-column"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/index/index:17",
                    "id": function () {return this.$item.id},
                    "className": "color-item",
                    "focusable": "true"
                  },
                  "type": "canvas",
                  "id": function () {return this.$item.id},
                  "events": {
                    "focus": function (evt) {this.swipeToIndex(this.$item.index,evt)}
                  },
                  "classList": [
                    "color-item"
                  ],
                  "repeat": function () {return this.canvasList}
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/index/index:22",
        "className": "cart"
      },
      "type": "div",
      "classList": [
        "cart"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/index/index:23",
            "className": "{{cartStyle}}",
            "focusable": "true",
            "value": function () {return this.cartText}
          },
          "type": "text",
          "classList": function () {return [this.cartStyle]},
          "events": {
            "click": "addCart",
            "focus": "getFocus",
            "blur": "lostFocus"
          }
        }
      ]
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.18\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!../../../../../hm_workspace/js_first/entry/src/main/js/default/pages/index/index.js":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/dev_hm/hmSdk/js/2.1.1.18/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/dev_hm/hm_workspace/js_first/entry/src/main/js/default/pages/index/index.js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _newArrowCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/newArrowCheck */ "./node_modules/@babel/runtime/helpers/newArrowCheck.js"));

var _default = {
  data: {
    cartText: 'Add To Cart',
    cartStyle: 'cart-text',
    isCartEmpty: true,
    descriptionFirstParagraph: 'This is the food page including fresh fruit, meat, snack and etc. You can pick whatever you like and add it to your Cart. Your order will arrive within 48 hours. We gurantee that our food is organic and healthy. Feel free to ask our 24h online service to explore more about our platform and products.',
    imageList: ['/common/food_000.jpg', '/common/food_001.jpg', '/common/food_002.jpg', '/common/food_003.jpg'],
    canvasList: [{
      id: 'cycle0',
      index: 0,
      color: '#f0b400'
    }, {
      id: 'cycle1',
      index: 1,
      color: '#e86063'
    }, {
      id: 'cycle2',
      index: 2,
      color: '#597a43'
    }, {
      id: 'cycle3',
      index: 3,
      color: '#e97d4c'
    }]
  },
  onShow: function onShow() {
    var _this = this;

    console.info("开始画了");
    this.canvasList.forEach(function (element) {
      (0, _newArrowCheck2["default"])(this, _this);
      this.drawCycle(element.id, element.color);
    }.bind(this));
  },
  swipeToIndex: function swipeToIndex(index) {
    this.$element('swiperImage').swipeTo({
      index: index
    });
  },
  drawCycle: function drawCycle(id, color) {
    var greenCycle = this.$element(id);
    var ctx = greenCycle.getContext("2d");
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(15, 25, 10, 0, 2 * 3.14);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
  },
  addCart: function addCart() {
    if (this.isCartEmpty) {
      this.cartText = 'Cart + 1';
      this.cartStyle = 'add-cart-text';
      this.isCartEmpty = false;
    }
  },
  getFocus: function getFocus() {
    if (this.isCartEmpty) {
      this.cartStyle = 'cart-text-focus';
    }
  },
  lostFocus: function lostFocus() {
    if (this.isCartEmpty) {
      this.cartStyle = 'cart-text';
    }
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/newArrowCheck.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/newArrowCheck.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _newArrowCheck(innerThis, boundThis) {
  if (innerThis !== boundThis) {
    throw new TypeError("Cannot instantiate an arrow function");
  }
}

module.exports = _newArrowCheck;

/***/ })

/******/ });
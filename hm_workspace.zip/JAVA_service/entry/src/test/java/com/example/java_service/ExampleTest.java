package com.example.java_service;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
